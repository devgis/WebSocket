﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SuperWebSocket")]
[assembly: AssemblyDescription("SuperWebSocket")]
[assembly: AssemblyConfiguration("")]
[assembly: ComVisible(false)]
[assembly: Guid("c987ab0e-8f0b-4d27-aae4-4649afba5fbe")]

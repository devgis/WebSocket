﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SuperWebSocket.Samples.JsonCommandAssembly.JsonObject
{
    public class AddParameter
    {
        public int A { get; set; }

        public int B { get; set; }
    }
}

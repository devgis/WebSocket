﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("SuperWebSocket")]
[assembly: AssemblyProduct("SuperWebSocket")]
[assembly: AssemblyCopyright("Copyright © SuperWebSocket 2010-2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("0.10.0.0")]
[assembly: AssemblyFileVersion("0.10.0.0")]
